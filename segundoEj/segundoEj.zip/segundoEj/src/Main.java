public class Main {

    public static void main(String[] args){

        Coche unCoche = new Coche();
        unCoche.agregarPuerta();
        unCoche.agregarPuerta();
        unCoche.agregarPuerta();
        unCoche.agregarPuerta();
        System.out.println(unCoche.cantidadDePuertas);
    }
}
