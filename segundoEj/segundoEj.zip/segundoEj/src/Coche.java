public class Coche {
    public int cantidadDePuertas = 0;

    public void agregarPuerta() {
        this.cantidadDePuertas++;
    }


}
