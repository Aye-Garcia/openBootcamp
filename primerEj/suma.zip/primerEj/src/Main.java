
public class Main {

    public static void main(String[] args) {
       suma(5, 10, 20);
    }

    public static void suma ( int n1, int n2, int n3) {
        int resultado;
        resultado = n1 + n2 + n3;

        System.out.println(resultado);
    }

}